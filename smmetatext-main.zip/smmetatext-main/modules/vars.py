api_id = "27862677"
api_hash = "e343ce2c81b2b6c2c0d6bee58284e3bd"
bot_token = "7063024370:AAFHuTYE6bOwjI5s3Nodv2mi8JGctq15nu0"
